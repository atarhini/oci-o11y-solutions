Content
Sources: [OEM AUDIT LOG]
Fields: [Job Type, Object Type, Operation Timestamp]

Reference
Fields: [clnthostip, clnthostname, comptype, eventtarget, eventtargettype, job, msg, object, oper, seq, sess, status, usrname]
